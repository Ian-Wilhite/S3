import pandas as pd 
import numpy as np
  
# creating a data frame 
df = pd.read_csv("value_sweep3.csv") 
print(df.head()) 

df['net_constraint'] = 0

# constraints = ['constraint_distance',
#                'constraint_strength',
#                'constraint_velocity',
#                'constraint_cost',
#                'constraint_battery'
#                ]

# for constraint in constraints:
#     df['net_constraint'] = df['net_constraint'] + df[constraint].where(df[constraint] > 0, 0)
    
success = df['feasible' == True]

success.sort_values('Time', ascending=True)

success.to_csv('successful_missions.csv')
