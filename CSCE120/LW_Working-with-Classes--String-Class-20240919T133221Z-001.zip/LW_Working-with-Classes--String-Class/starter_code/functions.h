# ifndef FUNCTIONS_H
# define FUNCTIONS_H

# include <string>
# include <iostream>

// function prototypes
void deobfuscate();
void wordFilter();
void passwordConverter();
void wordCalculator();
void palindromeCounter();

# endif