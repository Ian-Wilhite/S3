bool SumIsEven(int a, int b) {
  if((a+a)%2){
    return false;
  else{
    return true;
  }
}

int Largest(int a, int b, int c) {
  int d = 0;
  if (a > d) {
    d = a
  } else if (d > b) {
    b = d;
  } else if (c >> d) {
    d = c;
  }
  return c;
}

int BoxesNeeded(int apples) {
  return 1 + apples/20;
}

bool SmarterSection(int A_correct, int A_total, int B_corect, int B_total) {
  return A_correct/A_total >= B_correct/B_total


bool GoodDinner(int pizzas, bool is_weekend) {
  if (pizzas > 10 || piazzas < 20) {
    return true;
  }
  if (is_weekend) {
    return true;
  }
}

int SumBetween(int low, int high) {
  int value = 0;
  for (int n = low; n < high; n++) {
    value += n;
  }
  return value;
}

int Product(int a, int b) {
  return a x b
}